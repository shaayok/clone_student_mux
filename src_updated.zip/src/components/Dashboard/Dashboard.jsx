import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/Header/Header';
import Tabs from '../../components/Tabs/Tabs';
import LessonList from '../../components/LessonList/LessonList';
import VideoPanel from '../../components/VideoPanel/VideoPanel';
import styles from './Dashboard.module.css';
import { useAuth } from '../../hooks/useAuth';
import { getAllLessons } from '../../service/lesson.service';
import ClipLoader from 'react-spinners/ClipLoader';
import Sidear from '../Header/Sidebar';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const TABS = [
  { key: 'all',    label: 'Alle Lessen' },
  { key: 'recent', label: 'Recente'    },
  { key: 'older',  label: 'Oudere'     },
];

const NOLESSONTABS = [
  { key: 'all', label: 'Alle Lessen' }
];

export default function Dashboard() {
  const [activeTab, setActiveTab]   = useState('all');
  const [selectedId, setSelectedId] = useState(null);
  const [lessons, setLessons]       = useState([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);
  const [dataType, setDataType]     = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { logout }                  = useAuth();
  const navigate                    = useNavigate();

  let demoVideoObject = [
    {
      "id": "lYH664CyF3qIxQGCvtgrq4xmfRSL00TsyAY3vkLOpC2Q",
      "videos": 0,
      "date": "2025-06-20T00:00:00.000Z",
      "start": "2025-06-20T10:30:00.000Z",
      "end": "2025-06-20T10:30:38.000Z"
    }
  ];

  let demoVideoListObject = [
  {
    "id": "1",
    "name": "1. - 250225 verkeer van rechts",
    "url": "lYH664CyF3qIxQGCvtgrq4xmfRSL00TsyAY3vkLOpC2Q",
    "analysis": "**Positieve Punten:**\n1. **Stabiel Rijgedrag:** De leerling rijdt over het algemeen stabiel en houdt een redelijk constante positie op de weg aan in het begin van het fragment.\n2. **Passeren Witte Bestelbus:** Het passeren van de witte bestelbus (rond 0:09-0:11) lijkt adequaat te gebeuren. De leerling geeft voldoende ruimte.\n3. **Herkennen van Gevaar (Vrachtwagen + Rode Auto):** De leerling lijkt de potentieel gevaarlijke situatie met de naderende vrachtwagen en de rode auto die vanaf rechts de weg opdraait te herkennen, aangezien er een snelheidsvermindering waarneembaar is. \n**Aandachtspunten:**\n1. Anticipatie en Besluitvorming bij Complex Kruispunt/Uitrit:\n  - Situatie (0:12 - 0:21): De kern van deze video. Een vrachtwagen nadert op de hoofdweg. Tegelijkertijd komt een rode auto van rechts (lijkt een uitrit/zijweg) en wil de weg opdraaien, voor de vrachtwagen langs. De leerling bevindt zich achter de rode auto.\n  - Te Late of Twijfelachtige Reactie: De leerling mindert weliswaar vaart, maar het lijkt erop dat er enige twijfel is over wat te doen. De rode auto creëert een onzekere situatie. De leerling volgt relatief dicht op de rode auto.\n  - Afstand Houden: Zodra duidelijk wordt dat de rode auto de weg op wil en er een grote vrachtwagen aankomt, had de leerling proactiever meer afstand moeten creëren tot de rode auto. Dit geeft meer tijd en ruimte om de situatie te beoordelen en te reageren. Als de rode auto plotseling had moeten remmen (bijvoorbeeld omdat de vrachtwagen toch sneller was dan gedacht), had de leerling mogelijk te weinig ruimte.\n  - Kijkgedrag: Heeft de leerling de vrachtwagen en de rode auto goed in de gaten gehouden en de interactie tussen die twee correct ingeschat? De rode auto neemt een risico door voor de vrachtwagen langs te gaan. De leerling moet daarop voorbereid zijn.\n2. Plaats op de Weg na de Situatie:\n  - Nadat de rode auto en de vrachtwagen gepasseerd zijn (rond 0:21-0:23), lijkt de lesauto wat meer naar het midden van de weg te gaan. Het is belangrijk om na zo'n situatie weer de correcte, iets meer rechtse positie op de eigen weghelft in te nemen.\n3. Verwerking van Informatie (Verkeersborden):\n  - Aan de rechterkant (vanaf 0:13) is een rond blauw bord met een pijl naar links zichtbaar, wat waarschijnlijk een verplichte rijrichting of een gebod tot het volgen van die richting aangeeft voor een naderend kruispunt of afslag. Het is niet direct relevant voor deze specifieke situatie, maar het is wel belangrijk dat de leerling alle borden opmerkt en verwerkt.\nSamenvatting Instructiepunten:\n- Verhoogde Alertheid en Anticipatie bij Kruispunten/Uitritte: Leerlingen moeten getraind worden om extra alert te zijn bij plekken waar ander verkeer de weg kan opkomen of oversteken. Dit omvat het actief scannen van zijwegen en uitritten.\n- Defensief Rijden en Ruimte Creëren: In onzekere situaties, zoals met de rode auto die voorrang lijkt te nemen op de vrachtwagen, is het cruciaal om defensief te rijden. Dit betekent:\n  - Meer afstand houden tot het voorliggende voertuig.\n  - Snelheid tijdig aanpassen (liever iets te vroeg dan te laat).\n  - Voorbereid zijn op onverwachte acties van andere weggebruikers.\n- Besluitvaardigheid: Hoewel voorzichtigheid geboden is, moet een leerling ook leren om beslissingen te nemen. Als de situatie onveilig dreigt te worden, is tijdig en duidelijk vaart minderen of zelfs stoppen de juiste keuze.\n- Kijktechniek: Het belang van \"ver vooruit kijken, breed kijken, en dynamisch kijken\" (constant de omgeving scannen) benadrukken. Niet alleen focussen op de auto direct voor je, maar ook op wat er verderop en naast je gebeurt.\n- Correcte Plaats op de Weg: Na het oplossen van een complexe situatie, weer terugkeren naar de standaard, veilige positie op de weg."
  },
  {
    "id": "2",
    "name": "2. Kruispunt Zwembad hoe los jij dit op_",
    "url": "CAjnsIKHe26fsGa3ri6VrPga500TAzQu1nwkXKhLDJNI",
    "analysis": "Positieve Punten:\n1. 3) tijdig op te merken en vermindert snelheid. Dit is goed.\n2. Voorrang Verlenen aan Vrachtwagen: De leerling wacht correct tot de grote vrachtwagen gepasseerd is.\n3. Rust Bewaren (Grotendeels): Ondanks de complexe situatie met meerdere weggebruikers, lijkt de leerling over het algemeen rustig te blijven en geen paniekerige manoeuvres te maken.\n\nAandachtspunten:\n1. Anticipatie en Positionering bij Naderen Kruispunt/Verkeersplateau:\n  - Vroege Observatie (0:00-0:07): De weg heeft hier onderbroken asstrepen, wat kan duiden op naderende kruispunten of potentieel overstekend verkeer. De fietser links (0:05) wordt gepasseerd, maar is de leerling zich al bewust van het complexere kruispunt verderop?\n  - Verkeersbord (0:06-0:07 & 0:11-0:12): Er staat een gevaarsbord (driehoek met een kruis, J8 - gevaarlijk kruispunt) en daaronder een onderbord (lijkt op overstekende (brom)fietsers of schoolkinderen). Dit is een duidelijke waarschuwing die een nog hogere staat van paraatheid en snelheidsaanpassing vereist, voordat de vrachtwagen überhaupt in beeld komt.\n2. Omgaan met Meerdere Conflicterende Bewegingen (0:13 - Einde): Dit is de kern van de leerervaring hier.\n  - Na de Vrachtwagen: Nadat de vrachtwagen gepasseerd is, doemt een complex scenario op:\n    - Een auto (donker, mogelijk BMW) komt van links en lijkt voorrang te hebben of te nemen (0:14-0:15, lastig te zien wie voorrang heeft zonder de precieze layout te kennen, maar de leerling wacht).\n    - Fietsers: Cruciaal punt: Meerdere fietsers komen van links én van rechts en steken over (vanaf 0:15). Sommigen lijken het verkeersplateau/de oversteekplaats te gebruiken.\n  - Kijkgedrag en Prioritering:\n    - Het is essentieel dat de leerling constant scant: links, rechts, vooruit. Niet alleen focussen op de auto's.\n    - Fietsers zijn kwetsbaar en vereisen extra aandacht. De leerling moet actief zoeken naar fietsers en hun intenties inschatten.\n    - De auto die afslaat (0:26-0:28): Een donkere auto (BMW) slaat linksaf, voor de lesauto langs. Dit gebeurt terwijl er nog fietsers van rechts naderen/oversteken. Heeft de leerling deze interactie goed gezien en ingeschat? Er is een moment (0:27) dat de afslaande auto en een fietser van rechts elkaar bijna kruisen, vlak voor de lesauto.\n  - Besluitvorming \"Wanneer kan ik gaan?\":\n    - De leerling lijkt te wachten tot de meeste directe conflicten voorbij zijn, wat in principe goed is.\n    - Echter, er is een moment van aarzeling. Het is belangrijk om te leren inschatten wanneer er een veilig gat is om op te trekken, rekening houdend met álle verkeersdeelnemers.\n    - De donkere bestelbus die van links komt (0:29-0:30) en voorrang lijkt te hebben/nemen, dwingt de leerling uiteindelijk (terecht) te wachten. Was deze bus al eerder opgemerkt?\n\n3. Plaats op de Weg bij het Wachten:\n  - Bij het wachten op het kruispunt/plateau, zorg ervoor dat de auto zo gepositioneerd is dat ander verkeer (vooral fietsers) niet onnodig gehinderd wordt of zich onveilig voelt.\n\nSamenvatting Instructiepunten:\n- Betekenis Verkeersborden en Wegmarkeringen: Diepgaand begrip en directe reactie op gevaarsborden (J8) en onderborden. Dit moet leiden tot verhoogde alertheid en snelheidsaanpassing ruim van tevoren.\n- Scannen en Prioriteren bij Complexe Kruispunten:\n  - Systematisch scannen: \"links-rechts-links\" en constant herhalen.\n  - Actief zoeken naar kwetsbare verkeersdeelnemers (fietsers, voetgangers).\n  - Leren de interacties tussen andere verkeersdeelnemers te observeren en te voorspellen (bijv. de afslaande auto en de fietser).\n- Geduld en Defensief Rijden: Het is beter om iets langer te wachten en zeker te zijn van een veilige doorgang dan een risico te nemen. \"Bij twijfel, niet inhalen/oversteken/oprijden.\"\n- Communicatie (Indien Nodig): Hoewel niet direct zichtbaar of nodig hier, in sommige situaties kan oogcontact of een klein gebaar naar een fietser helpen om intenties duidelijk te maken.\n- Ruimtekussen: Ook bij het wachten, zorg voor voldoende ruimte om je heen en voor anderen.\n- Voorspellen van Gedrag: Proberen te anticiperen wat andere weggebruikers gaan doen. Een fietser die naar het kruispunt kijkt, gaat waarschijnlijk oversteken. Een auto die langzaam rijdt en richting aangeeft, gaat afslaan."
  },
  {
    "id": "3",
    "name": "3. - Passeer geparkeerde auto op gepaste afstand deur kan nog openslaan",
    "url": "2EjVt9DEuZRj4WYka017BvTj8nuDLvL4ku91rm00W4cFY",
    "analysis": "Positieve Punten:\n\nAangepaste Snelheid in Woonwijk: De leerling lijkt met een gepaste, lage snelheid te rijden, wat correct is voor een dergelijke omgeving met veel potentieel gevaar (geparkeerde auto's, overstekende personen, kruispunten).\nVoorzichtig Naderen Kruispunt: De leerling nadert het kruispunt aan het begin van de video (0:00-0:04) voorzichtig en lijkt goed te kijken.\nReactie op Auto van Rechts: De leerling wacht correct op de donkere auto die van rechts komt en voorrang heeft op het kruispunt (0:00-0:03).\nAandacht voor Fietser: De leerling laat de fietser die van links komt en het kruispunt oversteekt, correct voorgaan (0:03-0:04).\n\nAandachtspunten:\n\nKijktechniek en Anticiperen bij Geparkeerde Auto's:\n\"Deurzone\": De hele straat (vanaf 0:04) staat vol met geparkeerde auto's aan beide zijden. De leerling rijdt hier tussendoor. Het is cruciaal om constant de \"deurzone\" in de gaten te houden (de ruimte waarin een autodeur plotseling geopend kan worden). Is de leerling hier alert op?\nKinderen/Voetgangers tussen Auto's: Geparkeerde auto's ontnemen het zicht op voetgangers, vooral kinderen, die plotseling tussen de auto's door de weg op kunnen stappen. De snelheid moet hierop aangepast zijn, en de leerling moet continu \"scannen\" tussen en achter de geparkeerde auto's.\n\n- Uitparkerende Auto's: Wees alert op auto's die willen uitparkeren. Kijk naar signalen zoals achteruitrijlichten, bestuurders die instappen, etc.\n- Positionering op de Weg: Bij het rijden tussen twee rijen geparkeerde auto's, probeer zoveel mogelijk in het midden van de beschikbare (smalle) rijstrook te blijven om aan beide kanten een kleine veiligheidsmarge te hebben. Het is lastig te beoordelen met de fisheye-lens, maar het lijkt redelijk.\n- Tegenliggers (Potentieel): Hoewel er geen directe tegenliggers zijn in dit fragment, moet de leerling altijd anticiperen op de mogelijkheid van een tegenligger, vooral als de weg versmalt. Waar zou je uitwijken of stoppen als er een tegenligger komt? (Hier is de weg redelijk breed, maar het principe blijft.)\n- Observatie Voetgangers op Trottoir (0:15 - Einde):\nEr lopen voetgangers op het trottoir aan de rechterkant. Hoewel ze op het trottoir zijn, is het goed om ze in de gaten te houden. Een kind kan plotseling de straat op rennen, een hond kan losbreken, etc. Dit versterkt het belang van een lage, aangepaste snelheid.\n- \"Scanning\" Routine:\nIn zo'n omgeving is een actieve, constante \"scanning\" routine essentieel: spiegels, ver vooruit, dichtbij, tussen de auto's, stoepranden. Wordt dit consequent toegepast?\n\nSamenvatting Instructiepunten:\n\n- Gevaarherkenning in Woonwijken: Specifiek trainen op de gevaren van geparkeerde auto's:\nPlotseling openslaande portieren.\nKinderen/voetgangers die onverwacht oversteken.\nBeperkt zicht.\nUitparkerend verkeer.\n\n- \"Kijken, kijken, kijken\": Benadrukken van een intensieve kijkroutine, gericht op het vroegtijdig signaleren van potentiële gevaren. Niet alleen vooruit, maar ook breed en tussen objecten door.\nAangepaste Snelheid als Proactieve Maatregel: De snelheid moet zodanig zijn dat er altijd voldoende tijd is om te reageren op onverwachte gebeurtenissen. \"Rijden op zicht.\"\n\n- Positionering en Ruimtemanagement: Optimaal gebruikmaken van de beschikbare ruimte, met behoud van veiligheidsmarges. Weten waar je kunt stoppen of uitwijken indien nodig.\n\n- Anticiperen op Gedrag van Anderen: Vooral in woonwijken, waar het gedrag van andere weggebruikers (vooral voetgangers en spelende kinderen) minder voorspelbaar kan zijn.\n- Soepel en Rustig Rijden: Abrupte manoeuvres vermijden, wat bijdraagt aan de veiligheid en het comfort in een dergelijke omgeving."
 
  },
  {
    "id": "4",
    "name": "4. -uitrit van der Wal spoor",
    "url": "bqvcBcgpaiyE5HjkWqr87bU6HymyNOFh01n2t1yqYjK00",
    "analysis":"Positieve Punten:\n1. Aangepaste Snelheid (Initieel): De leerling rijdt met een rustige, aangepaste snelheid bij het naderen en passeren van het verkeersplateau/de snelheidsremmende maatregel in het begin (0:00-0:05).\n2. Opmerken Fietsers: De leerling lijkt de fietsers die van links en rechts komen op het fietspad bij het plateau (rond 0:09-0:14) op te merken.\n3. Herkennen van Naderende Voetgangersoversteekplaats (VOP): De leerling ziet de VOP en de naderende voetgangers (vanaf 0:17).\n4. Verlenen van Voorrang/Gelegenheid tot Oversteken aan Voetgangers: De leerling stopt correct en tijdig om de voetgangers de gelegenheid te geven veilig over te steken op de VOP (0:20-0:28). Dit getuigt van goed anticiperen en sociaal rijgedrag.\nAandachtspunten:\n1. \n  - Voetganger Rechts (0:01-0:06): Er loopt een voetganger op het trottoir rechts, die het plateau nadert. Goed om deze persoon in de gaten te houden, ook al steekt deze niet over.\n  - Zicht Beperkt door Zon: De zon staat hoog en schijnt fel. Bewustzijn van mogelijke verblinding en reflecties is belangrijk. Snelheidsaanpassing en eventueel gebruik van zonneklep zijn aandachtspunten.\n  - Kruisend Verkeer (Potentieel): Het plateau fungeert ook als kruising. Goed scannen naar links en rechts blijft belangrijk.\n2. Kijktechniek Ver Vooruit na het Plateau (0:10-0:17):\n  - Na het plateau is het essentieel om ver vooruit te kijken om de VOP en mogelijke voetgangers vroegtijdig te signaleren. De voetgangers komen relatief laat in het \"scherpe\" blikveld. Was de leerling al eerder aan het scannen op signalen die duiden op een oversteekplaats (verkeersborden die een VOP aankondigen, de fysieke constructie van de VOP zelf)?\n3. Afstand tot de VOP bij Stoppen:\n  - De leerling stopt op een goede afstand voor de VOP. Dit geeft voetgangers een veilig gevoel en goed overzicht.\n4. Communicatie en Besluitvorming bij VOP:\n  - Bij een VOP (die geen zebrapad is) hebben voetgangers niet automatisch voorrang. De bestuurder moet beoordelen of de voetgangers willen oversteken en hen, indien veilig en mogelijk, de gelegenheid geven. De leerling maakt hier de juiste sociale en veilige keuze door te stoppen. Duidelijk maken van intenties (door tijdig snelheid te minderen en te stoppen) is hier goed.\n  - \nSamenvatting Instructiepunten:\n- Proactief Scannen en Anticiperen:\n  - Continu de omgeving scannen, ver vooruit en breed, om VOP's en voetgangers met oversteekintenties zo vroeg mogelijk te identificeren.\n  - Niet alleen reageren op wat direct voor de auto gebeurt, maar voorspellen wat er kan gebeuren.\n- Omgaan met Beperkt Zicht (Zonlicht):\n  - Herkennen wanneer de zon het zicht belemmert.\n  - Snelheid aanpassen.\n  - Gebruik van hulpmiddelen (zonneklep).\n- Correct Handelen bij Voetgangersoversteekplaatsen (VOP's):\n  - Tijdig signaleren van de VOP (borden, constructie).\n  - Snelheid verminderen bij nadering.\n  - Goed observeren of er voetgangers (willen) oversteken en hun intenties inschatten.\n  - Beslissen of het veilig en sociaal is om te stoppen en voorrang/gelegenheid te verlenen.\n  - Duidelijk en op correcte afstand stoppen.\n- Interactie met Andere Weggebruikers:\n  - Bewust zijn van de aanwezigheid en intenties van fietsers en voetgangers.\n  - Defensief en sociaal rijgedrag: rekening houden met kwetsbare verkeersdeelnemers en hen waar mogelijk faciliteren."
  },
  {
    "id": "5",
    "name": "5. - uitrit waterpoort, altijd lastig",
    "url": "MyEMg1702BnMlSQE5FVaG1pRfNJn48rTjPY02qSQwxzkQ",
    "analysis":"Positieve Punten:\n1. Aangepaste Snelheid in Complex Gebied: De leerling handhaaft over het algemeen een lage, aangepaste snelheid, wat zeer gepast is voor deze drukke en smalle omgeving.\n2. Voorzichtigheid bij Fietsers: De leerling toont voorzichtigheid bij het passeren van en omgaan met de vele fietsers.\n  - Fietser van rechts bij begin (0:00-0:01): Correct voorrang gegeven/gewacht.\n  - Fietser die de weg oversteekt (0:19-0:21): Leerling wacht en geeft ruimte.\n3. Algemene Voertuigbeheersing: De auto wordt rustig en beheerst bestuurd door de smalle straten.\n4. Wachten op Bus: De leerling wacht geduldig tot de grote bus gepasseerd is (0:30-0:34), wat de juiste en veilige keuze is gezien de wegbreedte.\n\nAandachtspunten:\n1. Kijkgedrag en Anticiperen in een Dynamische Omgeving:\n  - \"Shared Space\" Gevoel: De omgeving heeft kenmerken van een \"shared space\" waar auto's, fietsers en voetgangers de ruimte delen, ook al zijn er trottoirs. Dit vereist een extreem hoog niveau van alertheid en anticiperen.\n  - Voorspellen Gedrag Fietsers: Fietsers kunnen onvoorspelbaar zijn. De leerling moet constant hun bewegingen en mogelijke intenties proberen te voorspellen (bijv. de fietser die plotseling de weg op lijkt te komen vanaf het trottoir bij 0:00).\n  - Zichtlijnen: Geparkeerde auto's (zoals de blauwe auto rechts bij 0:02-0:03 en verderop de grijze bestelbus en personenauto 0:08-0:15) beperken de zichtlijnen. Extra voorzichtigheid is geboden bij het passeren. Is de leerling alert op voetgangers die tussen de auto's vandaan kunnen komen?\n2. Positionering op de Smalle Weg:\n  - Passeren Geparkeerde Auto's en Tegenliggers (potentieel): Bij het passeren van de geparkeerde auto's, vooral als er (potentiële) tegenliggers zijn zoals de bestelbus (0:09-0:12) en later de grijze personenauto (0:12-0:16), is de positionering cruciaal. De leerling lijkt hier goed mee om te gaan door snelheid aan te passen en ruimte te zoeken. Echter, de vraag is of er nog eerder geanticipeerd kon worden op de noodzaak om te wachten of de snelheid sterk te minderen.\n  - Ruimte voor Fietsers: Bij het passeren van fietsers, zorg altijd voor voldoende zijdelingse ruimte (minimaal 1,5 meter indien mogelijk, anders snelheid sterk aanpassen of wachten). Dit lijkt over het algemeen goed te gaan.\n3. Omgaan met de \"Obstakels\" / Smalle Passages:\n  - De geparkeerde blauwe auto (0:02-0:03) en later de bestelbus en personenauto creëren versmallingen. De leerling moet goed inschatten of er voldoende ruimte is en of er tegenliggers (inclusief fietsers) zijn die eerst moeten passeren. De leerling stopt/wacht correct voor de grijze auto (0:14-0:16).\n4. Naderen Brug/Sluizencomplex (vanaf 0:37):\n  - De weg versmalt aanzienlijk bij het naderen van de historische poort/brug. Er zijn slagbomen zichtbaar.\n  - Verkeersborden: Zijn er borden die de doorgang regelen (bijv. eenrichtingsverkeer, voorrangsregels, breedtebeperking)? De leerling moet deze borden tijdig opmerken en begrijpen.\n  - Overzicht en Planning: Hier is het cruciaal om ver vooruit te kijken, de situatie te overzien en een plan te maken. Wie heeft voorrang? Kan ik passeren? Moet ik wachten? Er zijn fietsers en voetgangers in dit gebied.\n\nSamenvatting Instructiepunten:\n- Meester worden in \"Defensief en Sociaal Rijden\": Dit type omgeving vraagt om een rijstijl die constant rekening houdt met anderen, anticipeert op hun (onverwachte) acties en conflicten probeert te vermijden.\n- Intensief en Breed Kijkgedrag: Niet alleen recht vooruit, maar continu de hele omgeving scannen: stoepranden, tussen geparkeerde auto's, fietsers van alle kanten, spiegels.\n- Ruimtemanagement en Inschatten: Constant de eigen positie, de beschikbare ruimte en de bewegingen van anderen inschatten. Weten wanneer je kunt passeren en wanneer je moet wachten.\n- Communicatie (Verbaal en Non-verbaal): Hoewel niet direct zichtbaar, kan in dergelijke situaties oogcontact met fietsers of voetgangers helpen om intenties te verduidelijken. Duidelijk en tijdig remmen is ook een vorm van communicatie.\n- Geduld: In drukke stadscentra is geduld essentieel. Haastige beslissingen leiden tot risico's.\n- Specifieke Aandacht voor Smalle Passages en Historische Elementen: Begrijpen hoe om te gaan met versmallingen, bruggen, poorten, en de daarbij behorende verkeersregels en potentiële gevaren."
  },
  {
    "id": "6",
    "name": "6. - Verkeerslichten Ziekenhuis defect",
    "url": "EF4v8uT6koT6Qhv5sE8ah02nBEsBgYLTaquAE003T7dg00",
    "analysis": "Het beeld toont de leerling die een kruispunt nadert waar de verkeerslichten defect zijn, en vervolgens linksaf slaat op een volgend kruispunt.\nPositieve Punten:\n1. Stabiel Rijden op Rechte Weg: De leerling rijdt stabiel en houdt een goede positie aan op de weg in de aanloop naar het eerste kruispunt (0:00-0:18).\n\n2. Handelen bij Defecte Verkeerslichten (Eerste Kruispunt): De leerling rijdt door op het eerste kruispunt, wat overeenkomt met een situatie waarin verkeerslichten defect zijn en er geen andere stop- of voorrangsverplichting direct zichtbaar is op de eigen rijbaan.\n3. Snelheidsaanpassing bij Naderen Tweede Kruispunt: De leerling mindert snelheid bij het naderen van het kruispunt waar linksaf wordt geslagen (vanaf ongeveer 0:28).\n4. Correct Handelen t.o.v. Tegemoetkomend Verkeer bij Links Afslaan: De leerling wacht op de witte bestelbus (0:33-0:37) die rechtdoor gaat op dezelfde weg, alvorens linksaf te slaan op het tweede kruispunt.\nAandachtspunten:\n1. Eerste Kruispunt met Defecte Verkeerslichten (0:18 - 0:28):\n  - Toepassing Voorrangsregels bij Defecte Lichten: Bij defecte verkeerslichten zijn de ter plaatse geldende verkeersborden of verkeerstekens op de weg bepalend voor de voorrang. Indien deze ontbreken, gelden de algemene voorrangsregels.\n  - Naderingssnelheid: De naderingssnelheid en het doorrijden van het kruispunt met defecte lichten vereisen extra voorzichtigheid en een goed overzicht van de situatie.\n.\n2. Links Afslaan op het Tweede Kruispunt (vanaf 0:28):\n  - Voorsorteren: De leerling sorteert voor om linksaf te slaan.\n  - Positionering voor en tijdens Afslaan: De positionering op het kruispunt tijdens het wachten en het maken van de bocht is van belang voor een veilige en vlotte afwikkeling.\n  - Bochttechniek: De uitvoering van de bocht naar links.\nSamenvatting Instructiepunten:\n- Handelen bij Defecte Verkeerslichten:\n  - Herkennen van de Situatie: Adequaat reageren op niet-functionerende verkeerslichten.\n  - Voorrangsregels Toepassen: Het belang van het identificeren en toepassen van de geldende voorrangsregels (via borden, tekens, of algemene regels) in een dergelijke situatie.\n  - Aangepaste Nadering: Een kruispunt met defecte lichten met verhoogde voorzichtigheid en aangepaste snelheid naderen.\n- Links Afslaan op een Kruispunt:\n  - Voorrangsregels: Correct toepassen van de voorrangsregels, met name ten opzichte van tegemoetkomend verkeer.\n  - Voorsorteren en Positionering: Correct en tijdig voorsorteren en een juiste positie innemen voor en tijdens het afslaan.\n  - Bochttechniek: Een correct uitgevoerde bocht."
  },
  {
    "id": "7",
    "name": "7. - voorrangsrotonde IJlst met bus",
    "url": "oJKVauWDuHF5zE9JUBX4ZBHzWOI2RTVjnVE5u4z6CmA",
    "analysis":"Positieve Punten:\n1. Snelheidsaanpassing bij Naderen Rotonde: De leerling vermindert snelheid bij het naderen van de rotonde (vanaf 0:01).\n\n2. Correct Handelen t.o.v. Bus op Rotonde: De leerling wacht correct tot de grote gele bus, die zich al op de rotonde bevindt en van links nadert, is gepasseerd (0:07-0:18). Dit is conform de voorrangsregel (verkeer op de rotonde heeft doorgaans voorrang).\n3. Correct Handelen t.o.v. Witte Bestelbus: Nadat de gele bus is gepasseerd, wacht de leerling ook correct op de witte bestelbus die eveneens van links op de rotonde nadert (0:19-0:22).\n4. Oprijden Rotonde na Vrije Baan: De leerling rijdt de rotonde op nadat de bestelbus is gepasseerd en de weg vrij lijkt (0:23).\nAandachtspunten:\n1. Observatie Verkeersborden en -tekens bij Naderen Rotonde:\n  - Borden (B6/B7, haaientanden): Bij het naderen van een rotonde zijn de verkeersborden (B6 - verleen voorrang aan bestuurders op de kruisende weg, vaak in combinatie met haaientanden op het wegdek) cruciaal. Deze bevestigen dat verkeer op de rotonde voorrang heeft. De video toont haaientanden op het wegdek (zichtbaar vanaf 0:06), wat de leerling correct lijkt te interpreteren door te wachten. De aanwezigheid van de borden zelf is niet direct scherp in beeld, maar de markering wel.\n2. Richting Aangeven bij Naderen en Verlaten:\n  - Bij Naderen (Indien 1e Afslag): Als de intentie is om de rotonde bij de eerste afslag te verlaten, dient men voor het oprijden van de rotonde richting naar rechts aan te geven.\n  - Bij Verlaten: Bij het verlaten van de rotonde dient men altijdtijdig richting naar rechts aan te geven. De video stopt voordat dit moment duidelijk wordt, maar het is een belangrijk aandachtspunt.\n3. Positionering op de Rotonde:\n  - De leerling rijdt de rotonde op. De gekozen positie op de rotonde zelf (meer rechts voor de eerste/tweede afslag, meer links voor latere afslagen) is van belang voor de duidelijkheid naar ander verkeer en een correcte afwikkeling. Dit is in het korte fragment na het oprijden nog niet volledig te beoordelen.\n4. Snelheid en Vlotheid bij Oprijden:\n  - Nadat de bestelbus is gepasseerd (0:22), lijkt er een moment van lichte aarzeling te zijn voordat de leerling de rotonde oprijdt (0:23). Hoewel voorzichtigheid goed is, is het ook belangrijk om, wanneer de situatie het toelaat, vlot en besluitvaardig de rotonde op te rijden om de doorstroming niet onnodig te belemmeren. Er lijkt een redelijk gat in het verkeer te zijn na de bestelbus. De grijze auto die volgt (0:25) is nog op enige afstand.\n\nSamenvatting Instructiepunten:\n- Rotondes – Verkeersregels en Tekens:\n  - Herkennen en Interpreteren: Het belang van het herkennen van de rotonde-aankondigingsborden, voorrangsborden (B6/B7), en wegmarkeringen (haaientanden).\n  - Voorrangsregels Toepassen: Consequent voorrang verlenen aan verkeer op de rotonde.\n- Rotondes – Uitvoering:\n  - Snelheidsaanpassing: Tijdig en adequaat snelheid aanpassen bij nadering.\n  - Richting Aangeven: Correct en tijdig gebruik van richtingaanwijzers (bij naderen voor 1e afslag, altijd bij verlaten).\n  - Positionering: Kiezen van de juiste positie op de rotonde afhankelijk van de te volgen route.\n  - Besluitvaardigheid: Vlot oprijden wanneer de situatie veilig is, om de doorstroming te bevorderen.\n- Doorstroming en Veiligheid: Het vinden van de balans tussen voorzichtigheid en het vlot deelnemen aan het verkeer."
  },
  {
    "id": "8",
    "name": "8. - waterpoort voorrang geven en inhalen",
    "url": "D102TgBkEzUkgAKUbJ8X6PsgVJXG01J02DVdz1qYPfQwMc",
    "analysis": "Het beeld toont de leerling rijdend door een smalle straat in een historisch centrum, langs een gracht, met diverse interacties en het naderen van een brug/poort.\nPositieve Punten:\n1. Aangepaste Snelheid: De leerling handhaaft over het algemeen een lage en aangepaste snelheid, wat correct is voor deze complexe en potentieel drukke omgeving.\n2. Geduldig Wachten op Bus: De leerling stopt en wacht geduldig tot de bus (0:06-0:09) de smalle passage heeft verlaten. Dit is een goede, veilige beslissing.\n3. Correct Handelen t.o.v. Tegemoetkomende Auto's: De leerling wacht op de blauwe auto (0:10-0:11) en vervolgens op de stroom van meerdere auto's (zilveren stationwagen 0:12-0:14, donkere SUV 0:17-0:19, etc.) alvorens zelf door te rijden. Dit toont correcte toepassing van voorrang (of het creëren van een veilige doorgang) in smalle situaties.\n4. Voorzichtig Naderen Brug/Poort: De leerling nadert de brug/poort aan het einde van de video (vanaf 0:22) met lage snelheid.\nAandachtspunten:\n1. Positionering bij Wachten en Passeren:\n  - Bij Wachten op Bus (0:06-0:09): De leerling stopt. De positie op de weg is hierbij van belang om de doorgang voor eventueel ander verkeer (fietsers) niet onnodig te blokkeren, hoewel de ruimte beperkt is.\n  - Bij Wachten op Tegemoetkomende Auto's (0:10-0:22): De leerling stopt en wacht. Het is belangrijk om hierbij een positie in te nemen die duidelijk maakt dat men wacht en die voldoende ruimte laat voor het passerende verkeer. De leerling lijkt hier goed te handelen door ruimte te geven.\n2. Besluitvorming \"Wanneer Doorrijden?\":\n  - Na het passeren van de stroom auto's (rond 0:21-0:22), is er een moment van beoordeling voordat de leerling weer optrekt. Het is belangrijk om hierbij niet alleen naar direct naderende auto's te kijken, maar ook verder vooruit te plannen, rekening houdend met de naderende brug/poort en eventueel verkeer dat daarvandaan komt. De witte pick-up truck (0:29-0:34) die van de brug afkomt, wordt correct doorgelaten.\n3. Verkeersborden en -regels bij Brug/Poort:\n  - Bij het naderen van de brug/poort (vanaf 0:22) zijn er verkeersborden zichtbaar (o.a. een P-zone bord, en mogelijk borden die de voorrang of doorgang bij de versmalling regelen). Het is cruciaal dat de leerling deze borden tijdig waarneemt en de instructies correct interpreteert. De slagbomen suggereren een beweegbare brug of een gereguleerde doorgang.\n4. Anticiperen op Verkeer van de Brug/Poort:\n  - De leerling wacht correct op de witte pick-up truck. Het is belangrijk om ver genoeg voor de versmalling te wachten om een veilige passage voor beide voertuigen mogelijk te maken.\n\nSamenvatting Instructiepunten:\n- Rijden in Smalle Straten/Historische Centra:\n  - Verhoogde Alertheid: Dit soort omgevingen vereist constante alertheid.\n  - Snelheidsmanagement: Altijd een lage, aangepaste snelheid aanhouden.\n  - Ruimtelijk Inzicht: Goed kunnen inschatten van de eigen voertuigbreedte en de beschikbare ruimte.\n- Omgaan met Tegemoetkomend Verkeer in Versmallingen:\n  - Voorrangsregels/Goede Afspraken: Weten wanneer men voorrang heeft of moet verlenen, of in onduidelijke situaties door middel van communicatie (oogcontact, gebaren, of simpelweg wachten) tot een veilige oplossing komen.\n  - Geduld: Vaak is wachten de veiligste optie.\n- Interpreteren van Verkeersborden en -situaties:\n  - Specifieke aandacht voor borden die de doorgang bij versmallingen, bruggen, of gereguleerde zones aangeven.\n- Besluitvaardigheid:\n  - Na het wachten, vlot en besluitvaardig doorrijden wanneer de situatie veilig is, om de doorstroming niet onnodig te hinderen."
  }
];

  useEffect(() => {
    (async () => {
      try {
        const all = await getAllLessons();
        if (Array.isArray(all) && all.length > 0) {
          setLessons(all);
          setDataType('real');
        } else {
          setLessons(demoVideoObject);
          setDataType('demo');
        }
      } catch (err) {
        // toast.error('Lessen laden mislukt');
        // console.error(err);
        // setError('Lessen laden mislukt');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const sortedLessons = useMemo(() => {
    return [...lessons].sort((a, b) => b.date - a.date);
  }, [lessons]);

  useEffect(() => {
    if (sortedLessons.length && !selectedId) {
      setSelectedId(sortedLessons[0].id);
    }
  }, [sortedLessons, selectedId]);

  const filtered = useMemo(() => {
    if (activeTab === 'recent') return sortedLessons.slice(0, 5);
    if (activeTab === 'older')  return sortedLessons.slice(5);
    return sortedLessons;
  }, [activeTab, sortedLessons]);

  useEffect(() => {
    if (selectedId && !filtered.find(l => l.id === selectedId)) {
      setSelectedId(null);
    }
  }, [filtered, selectedId]);

  const selectedLesson = sortedLessons.find(l => l.id === selectedId);

  const handleMenuClick = () => {
    setIsSidebarOpen(true); // Opens the sidebar
  };

  const handleSidebarClose = () => {
    setIsSidebarOpen(false); // Closes the sidebar
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  if (loading) {
    return <div className={styles.loading}><ClipLoader size={40} color="#4968f1" /></div>;
  }

  // if (error) {
  //   return <div className={styles.error}>{error}</div>;
  // }

  if (!lessons.length) {
    return (
      <div className={styles.container}>
        <Header title="Leerling Dashboard" onLogout={handleLogout} />
        <div className={styles.noLessons}>
          Geen lessen gevonden.<br />
          Neem contact op met je instructeur.
        </div>
      </div>
    );
  }

  return (
    <>
    <div className={styles.container}>
      <ToastContainer position="top-right" autoClose={3000} />
      <Header title="Leerling Dashboard" onLogout={handleLogout} />
      <Sidear 
        isOpen={isSidebarOpen}
        onClose={handleSidebarClose} // This closes the sidebar
        onLogout={handleLogout}
      />

      <div className={styles.body}>
        <div className={styles.content}>
          <aside className={styles.sidebar}>
            <Tabs
              tabs={dataType==='real' ? TABS : NOLESSONTABS}
              activeTab={activeTab}
              onChange={setActiveTab}
            />

            <div className={styles.lessonListContainer}>
              <LessonList
                lessons={filtered}
                selectedId={selectedId}
                onSelect={setSelectedId}
              />
            </div>
          </aside>

          <main className={styles.main}>
            <VideoPanel selectedLesson={selectedLesson} dataType={dataType} demoVideoListObject={demoVideoListObject} />
          </main>
        </div>
      </div>
    </div>
    </>
  );
}
